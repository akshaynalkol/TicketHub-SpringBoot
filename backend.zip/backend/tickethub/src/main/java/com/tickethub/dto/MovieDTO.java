package com.tickethub.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MovieDTO {
	private Long id;
	private String title;
	private String overview;
	private double vote_average;
	private int vote_count;
	private String release_date;
	private String movieStatus;
	private String backdrop_path;
	private String poster_path;
}
