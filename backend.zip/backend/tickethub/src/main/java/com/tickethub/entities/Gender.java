package com.tickethub.entities;

public enum Gender {
	MALE, FEMALE;
}
