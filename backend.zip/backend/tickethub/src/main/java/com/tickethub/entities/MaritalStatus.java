package com.tickethub.entities;

public enum MaritalStatus {
	MARRIED, UNMARRIED;
}
