import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { AppRouter } from './components/AppRouter';

function App() {

  return (
    <>
      <Router>
        <AppRouter />
      </Router>
      {/* <TicketBook /> */}
      {/* <NavBar />
      <Banner />
      <Upcoming />
      <NowPlaying />
      <Box />
      <CustomEvent />
      <Movie /> */}
    </>
  )
}

export default App
