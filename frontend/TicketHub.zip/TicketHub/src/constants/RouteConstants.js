export const ROUTES = Object.freeze({
    LOGIN:"/",
    ADD_PRODUCT:"/add-product",
    PRODUCTS_LIST: "/products-list",
    EDIT_PRODUCT:"/edit-product",
    HOME:"/home"
});